import torch
import torch.nn as nn
from torchvision import transforms, models
from torchvision.datasets import ImageFolder
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
import numpy as np
import os
from PIL import Image
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay


test_dir = r"C:/Users/laksh/OneDrive/Desktop/coding/Circuitguard_Project/preprocessing/output_dataset/test"
model_path = r"C:\Users\laksh\OneDrive\Desktop\coding\Circuitguard_Project\training\best_model.pth"
output_annotated_dir = r"C:/Users/laksh/OneDrive/Desktop/coding/Circuitguard_Project/test_results"
os.makedirs(output_annotated_dir, exist_ok=True)


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

test_transform = transforms.Compose([
    transforms.Resize((128,128)),
    transforms.ToTensor(),
    transforms.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225])
])

test_dataset = ImageFolder(test_dir, transform=test_transform)
test_loader = DataLoader(test_dataset, batch_size=16, shuffle=False, num_workers=0)

num_classes = len(test_dataset.classes)
model = models.efficientnet_b4(weights=None) 
model.classifier = nn.Sequential(
    nn.Dropout(p=0.4, inplace=True),
    nn.Linear(model.classifier[1].in_features, num_classes)
)
model.load_state_dict(torch.load(model_path, map_location=device))
model = model.to(device)
model.eval()

all_preds, all_labels = [], []
with torch.no_grad():
    for imgs, labels in test_loader:
        imgs, labels = imgs.to(device), labels.to(device)
        outputs = model(imgs)
        _, preds = torch.max(outputs, 1)
        all_preds.extend(preds.cpu().numpy())
        all_labels.extend(labels.cpu().numpy())


cm = confusion_matrix(all_labels, all_preds)
disp = ConfusionMatrixDisplay(cm, display_labels=test_dataset.classes)
disp.plot(cmap=plt.cm.Blues)
plt.title("Confusion Matrix")
plt.show()

for idx, (img_path, _) in enumerate(test_dataset.samples):
    img = Image.open(img_path).convert("RGB")
    label_name = test_dataset.classes[all_preds[idx]]
    plt.figure()
    plt.imshow(img)
    plt.title(f"Predicted: {label_name}")
    plt.axis('off')
    save_path = os.path.join(output_annotated_dir, f"annotated_{os.path.basename(img_path)}")
    plt.savefig(save_path, bbox_inches='tight')
    plt.close()

print(" Predictions done! Annotated images saved in:", output_annotated_dir)
